autores = []
autor = ''
tm = open('OmegaT-L10N-omegat.tmx', 'r')
todasLinhas = tm.read()
linhas = todasLinhas.split('\n')
for j in range(0, len(linhas)):
	pos = linhas[j].find('changeid=')
	if pos > -1:
		while linhas[j][pos+10] != '"':
			autor += linhas[j][pos+10]
			pos += 1
		if autor not in autores:
			autores.append(autor.strip('"'))
		autor = ''
tm.close()
listaFinal = open('listaFinal.txt', 'w')
listaFinal.write(f'{str(len(autores))}\n')
listaFinal.write(str(autores))
listaFinal.close()
print(autores)