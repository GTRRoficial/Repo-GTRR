import pyautogui, time, pyperclip
from bs4 import BeautifulSoup

def copiaPagina():
    pyautogui.click(1102, 378)
    time.sleep(0.5)
    pyautogui.hotkey('ctrl', 'l')
    time.sleep(0.5)
    pyautogui.hotkey('ctrl', 'v')
    time.sleep(0.5)
    pyautogui.press('enter')
    time.sleep(1)
    pyautogui.click(1102, 378)
    time.sleep(0.5)
    pyautogui.hotkey('ctrl', 'a')
    time.sleep(0.5)
    pyautogui.hotkey('ctrl', 'c')
    time.sleep(0.5)

with open('wikiaSite.txt','r') as arquivoInicial, open('wikiaText.txt','a+') as arquivoFinal:
    for linha in arquivoInicial:
        linhaLimpa = str(linha).strip()
        urlSite = (f'view-source:https://cookingdash2016.fandom.com/wiki/{linhaLimpa}/Entr%C3%A9es')
        pyperclip.copy(urlSite)
        copiaPagina()
        conteudoPagina = pyperclip.paste()
        bsObj = BeautifulSoup(conteudoPagina, "html.parser")
        listaTitle = bsObj.find('title').get_text().strip(' | Cooking Dash 2016 Wikia | Fandom').split('/')
        arquivoFinal.write(f'\n** {listaTitle[0]} **\n')
        lista1 = bsObj.find_all('div', {'class':"header"})
        lista2 = bsObj.find_all('div', {'class':"navigation"})
        print(len(lista1), len(lista2))
        a = 0
        for text in lista1:
            conteudoClasse = text.get_text().strip('[edit]')
            if conteudoClasse:
                arquivoFinal.write(f'{conteudoClasse.strip()} - ')
                if '(no information)' not in conteudoClasse:
                    arquivoFinal.write(f'{lista2[a+1].get_text()} - ')
                    arquivoFinal.write(f'{lista2[a+2].get_text()}')
                arquivoFinal.write(f'\n')
                a+=3
                if a+2 > (len(lista2)):
                    break

pyautogui.hotkey('alt', 'tab')