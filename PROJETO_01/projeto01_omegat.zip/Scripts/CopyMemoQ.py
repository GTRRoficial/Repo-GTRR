import pyautogui, time, clipboard
tm = []

for j in range(1,2):
    pyautogui.click(610, 274)
    pyautogui.hotkey('ctrl', 'a')
    time.sleep(0.5)
    pyautogui.hotkey('ctrl', 'c')
    time.sleep(0.5)
    port = clipboard.paste()
    tm.append(port)
    pyautogui.hotkey('tab')
    time.sleep(1)
    pyautogui.hotkey('ctrl', 'a')
    time.sleep(0.5)
    pyautogui.hotkey('ctrl', 'c')
    time.sleep(0.5)
    ing = clipboard.paste()
    tm.append(ing)

print(tm)