listaDA, listaSheila = [], []

with open('arquivos/Sheila/listaSheila.txt','r') as arquivoSheila, open('arquivos/DA/listaDA.txt','r') as arquivoDA:
    for linha in arquivoDA:
        linha = linha.strip('\n')
        listaDA.append(linha)
    for item in arquivoSheila:
        item = item.strip('\n')
        listaSheila.append(item)

for a in range(1, len(listaDA)-1):
    if listaDA[a] in listaSheila:
        f = open(f'arquivos/Sheila/{listaDA[a]}', 'r')
        g = open(f'arquivos/DA/{listaDA[a]}', 'a+')
        h = f.read()
        g.write(h)
        f.close()
        g.close()